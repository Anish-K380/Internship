export const displayConfig = {
    node: {
        normal: {
            fields: ['label'],
            style: 'normal'
        },

        hover: {
            fields: ['label', 'type', 'id'],
            style: 'hover'
        },

        click: {
            fields: ['label', 'type', 'id', 'metadata'],
            style: 'selected'
        }
    },

    style: {
        node: {
            normal: {
                fill: '#ffffff',
                stroke: '#9ca3af',
                strokeWidth: 1.5,
                textColor: '#111827'
            },

            hover: {
                fill: '#f8fafc',
                stroke: '#2563eb',
                strokeWidth: 2.5,
                textColor: '#111827'
            },

            selected: {
                fill: '#faf5ff',
                stroke: '#7c3aed',
                strokeWidth: 2.5,
                textColor: '#111827'
            }
        },

        edge: {
            stroke: '#94a3b8',
            strokeWidth: 1.5,
            opacity: 0.8
        },

        panel: {
            hover: {
                width: 400,
                padding: 10,
		fixedScreenSize: true
            },

            click: {
                width: 600,
                padding: 12,
		fixedScreenSize: true
            }
        }
    }
};
